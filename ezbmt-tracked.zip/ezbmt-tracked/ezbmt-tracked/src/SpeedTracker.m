#import <VisionCamera/FrameProcessorPlugin.h>
#import <ezbmt-Swift.h>  

VISION_EXPORT_SWIFT_FRAME_PROCESSOR(SpeedTracker, SpeedTracker)
