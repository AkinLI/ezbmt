export type Backend = 'sqlite' | 'supabase';
export const BACKEND: Backend = 'supabase'; // 調整這行即可切換
